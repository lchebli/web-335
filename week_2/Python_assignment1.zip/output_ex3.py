""" 
    Title: output_ex3.py
    Author: Professor Krasso
    Date: 11 August 2022
    Description: Example file for outputting values.
"""

print('2 + 2 = %d' % (2+2))