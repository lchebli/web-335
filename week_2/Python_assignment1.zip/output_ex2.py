""" 
    Title: output_ex2.py
    Author: Professor Krasso
    Date: 11 August 2022
    Description: Example file for outputting values.
"""

print('Python is fun to learn!!!')