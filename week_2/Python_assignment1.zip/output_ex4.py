""" 
    Title: output_ex4.py
    Author: Professor Krasso
    Date: 11 August 2022
    Description: Example file for outputting values.
"""

print('My name is {0}'.format('Professor Krasso'))
print('My favorite course to teach is {0}'.format('WEB 450 - Mastering the MEAN Stack!'))