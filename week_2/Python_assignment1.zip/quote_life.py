"""
Author: Leslie Khattarcheblli
Date: August 24, 2025
Title: quote_life.py
Description: This program prints a quote and gives credit the author.
"""

# Print the quote and author
print("All I know is that I know nothing")
print("- Socrates")
