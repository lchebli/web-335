""" 
    Title: output_ex1.py
    Author: Professor Krasso
    Date: 11 August 2022
    Description: Example file for outputting values.
"""

print('Welcome to WEB 335 - Introduction to NoSQL')